//
//  Level.h
//  Draconia
//
//  Created by Simon Maurice on 12/08/09.
//  Copyright 2009 Simon Maurice. All rights reserved.
//
// Draconia is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// Draconia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

// First some defines on the background
#define BACKGROUND_TILE_SIZE		64
#define BACKGROUND_COLUMNS			9
#define BACKGROUND_ROWS				4
#define BACKGROUND_SCROLL_SPEED		0.3
#define BACKGROUND_WRAP_X			BACKGROUND_TILE_SIZE*(BACKGROUND_COLUMNS-1)-BACKGROUND_SCROLL_SPEED
#define BACKGROUND_TILE_COUNT		BACKGROUND_ROWS*BACKGROUND_COLUMNS

@interface Level : NSObject {
	GLfloat backVerts[BACKGROUND_TILE_COUNT*8];		// Vertex array for all the background tiles
	GLuint backgroundTexture;						// OpenGL holder for the texture ID
	GLbyte backSTs[8];								// ST co-ordinates for the tiles. Only need one quad as they are all the same.
}

- (id)initWithFile:(NSString *)filename;
- (void)scroll;
- (void)drawBackground;
- (void)loadTexture:(NSString *)fileName intoLocation:(GLuint)location;
@end
