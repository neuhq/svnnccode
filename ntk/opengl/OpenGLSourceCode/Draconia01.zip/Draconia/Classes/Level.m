//
//  Level.m
//  Draconia
//
//  Created by Simon Maurice on 12/08/09.
//  Copyright 2009 Simon Maurice. All rights reserved.
//
// Draconia is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// Draconia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#import "Level.h"


@implementation Level

- (id)initWithFile:(NSString *)filename {
    if (self = [super init]) {
        
        // Code for initialising the background
        GLfloat xpos = 0.0;
        GLfloat ypos = BACKGROUND_TILE_SIZE;  // Offset the base to allow for the console
        
        for (int i = 0; i < BACKGROUND_COLUMNS; i++) {
            for (int j = 0; j < BACKGROUND_ROWS; j++) {
                int idx = i*BACKGROUND_ROWS*8 + (j*8);          // Just to make the code neater
                
                backVerts[idx] = xpos;                          // Top left
                backVerts[idx+1] = ypos + BACKGROUND_TILE_SIZE;
                backVerts[idx+2] = xpos;                        // Bottom left
                backVerts[idx+3] = ypos;
                backVerts[idx+4] = xpos + BACKGROUND_TILE_SIZE;       // Bottom right
                backVerts[idx+5] = ypos;
                backVerts[idx+6] = xpos + BACKGROUND_TILE_SIZE;       // Top right
                backVerts[idx+7] = ypos + BACKGROUND_TILE_SIZE;
				
				NSLog(@"Vertices for (%d, %d): %f, %f  %f, %f  %f, %f  %f, %f", i, j, backVerts[idx],
				backVerts[idx+1], backVerts[idx+2], backVerts[idx+3], backVerts[idx+4], backVerts[idx+5], backVerts[idx+6],
					  backVerts[idx+7]);
                
                ypos += BACKGROUND_TILE_SIZE;                         // Increase the y value to the next tile position
            }
            ypos = BACKGROUND_TILE_SIZE;                              // Reset the Y value to the bottom
            xpos += BACKGROUND_TILE_SIZE;                             // Move to the next column across
        }
        
        glGenTextures(1, &backgroundTexture);
        [self loadTexture:@"bluebackground.png" intoLocation:backgroundTexture];
        
        // Setup the texture co-ordinates (STs)
        backSTs[0] = 0;
        backSTs[1] = 1;
        backSTs[2] = 0;
        backSTs[3] = 0;
        backSTs[4] = 1;
        backSTs[5] = 0;
        backSTs[6] = 1;
        backSTs[7] = 1;
    }
    return self;
}

- (void)scroll {
	// Now Scroll the background. We only scroll the background if we have needed to scroll the foreground.
	// Again, we check for wrapping.
	for (int i = 0; i < BACKGROUND_TILE_COUNT; i++) {
		if (backVerts[i*8] < -BACKGROUND_TILE_SIZE) {
			backVerts[i*8] = BACKGROUND_WRAP_X;
			backVerts[i*8+2] = BACKGROUND_WRAP_X;
			backVerts[i*8+4] = BACKGROUND_WRAP_X + BACKGROUND_TILE_SIZE;
			backVerts[i*8+6] = BACKGROUND_WRAP_X + BACKGROUND_TILE_SIZE;
		} else {
			backVerts[i*8] -= BACKGROUND_SCROLL_SPEED;
			backVerts[i*8+2] -= BACKGROUND_SCROLL_SPEED;
			backVerts[i*8+4] -= BACKGROUND_SCROLL_SPEED;
			backVerts[i*8+6] -= BACKGROUND_SCROLL_SPEED;
		}
	}
}

- (void)drawBackground {
	
	// Draw that bad boy
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnable(GL_TEXTURE_2D);
	
	glTexCoordPointer(2, GL_BYTE, 0, backSTs);
	GLfloat *v = backVerts;
	glBindTexture(GL_TEXTURE_2D, backgroundTexture);
	for (int i = 0; i <= BACKGROUND_TILE_COUNT; i++) {
		glVertexPointer(2, GL_FLOAT, 0, v);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
		v = &backVerts[i*8];
	}
	
	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

- (void)loadTexture:(NSString *)fileName intoLocation:(GLuint)location {
	CGImageRef textureImage = [UIImage imageNamed:fileName].CGImage;
	
	if (textureImage == nil) {
		NSLog(@"Could not open image: %@", fileName);
		return;
	}
	
	NSInteger texWidth = CGImageGetWidth(textureImage);
	NSInteger texHeight = CGImageGetHeight(textureImage);
	
	GLubyte *textureData = (GLubyte *)malloc(texWidth * texHeight * 4);
	
	CGContextRef textureContext = CGBitmapContextCreate(textureData,
														texWidth, texHeight,
														8, texWidth * 4,
														CGImageGetColorSpace(textureImage),
														kCGImageAlphaPremultipliedLast);
	
	CGContextTranslateCTM(textureContext, 0, texHeight);
	CGContextScaleCTM(textureContext, 1.0, -1.0);
	
	CGContextDrawImage(textureContext, CGRectMake(0.0, 0.0, (float)texWidth, (float)texHeight), textureImage);
	CGContextRelease(textureContext);
	
	glBindTexture(GL_TEXTURE_2D, location);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texWidth, texHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData);
	
	free(textureData);
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}
	
- (void)dealloc {
	glDeleteTextures(1, &backgroundTexture);
	[super dealloc];
}


@end
